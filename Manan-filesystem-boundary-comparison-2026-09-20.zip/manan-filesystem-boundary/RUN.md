# Filesystem boundary comparison

FreshCtx 0.16.0 at commit `6e8e5b5cb3f887d9d2203599b2b159f96f34c109` · Python 3.11.15.

From this repository's root, run `PYTHONPATH=src python examples/manan_filesystem_boundary/run.py --output /tmp/manan-boundary-new`. Use a new output directory each time. The included `evidence/` is the recorded run.

Both isolated arms start with the same available slot, freeze the same booking action, and change the slot to unavailable before dispatch. The protected arm calls `ctx.run`; the direct arm invokes that same action without a FreshCtx check. `booking-effects.jsonl` is the synthetic action effect. The runner writes the observed effects and event trace for each arm. The protected arm also includes native FreshCtx audit JSONL with only temporary workspace paths replaced by `fixture://workspace`.

Open `evidence/comparison.json`, then each arm's `trace.jsonl`, `effects.json`, and `freshctx-audit.sanitized.jsonl`. This is a controlled filesystem test on our side; it does not test StareBrain, Calendar, or a remote transaction.
