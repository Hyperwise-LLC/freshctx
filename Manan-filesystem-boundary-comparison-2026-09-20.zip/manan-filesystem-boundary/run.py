"""Run the same stale booking decision with and without a FreshCtx boundary."""
from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

from freshctx import FreshnessBlocked, MemoryStore, guard, observe, reasoning


INITIAL = {"slot": "2030-04-10T10:00:00Z", "available": True, "version": 7}
CHANGED = {"slot": INITIAL["slot"], "available": False, "version": 8}
ACTION = {"action": "dispatch_booking", "slot": INITIAL["slot"], "planned_from_version": 7}


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, sort_keys=True) + "\n", encoding="utf-8")


def snapshot(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def run_arm(output: Path, arm: str) -> dict:
    with tempfile.TemporaryDirectory(prefix="freshctx-manan-") as temporary:
        work = Path(temporary)
        source = work / "slot.json"
        effect = work / "booking-effects.jsonl"
        audit = work / "freshctx-audit.jsonl"
        trace = []

        def record(step: str, **details: object) -> None:
            trace.append({"sequence": len(trace) + 1, "step": step, **details})

        write_json(source, INITIAL)
        record("source_observed", value=snapshot(source))
        store = MemoryStore()
        with guard(policy="block", store=store, run_id=arm, audit_path=audit):
            evidence = observe(source)
            with reasoning("approve_booking", depends_on=[evidence]) as decision:
                planned = dict(ACTION)
        record("decision_frozen", action=planned, observation_id=evidence.id, reasoning_id=decision.id)

        write_json(source, CHANGED)
        record("source_changed_before_dispatch", value=snapshot(source))

        def dispatch_booking(action: dict) -> None:
            with effect.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(action, sort_keys=True) + "\n")
            record("handler_entered_and_effect_written", action=action)

        if arm == "protected":
            try:
                with guard(policy="block", store=store, run_id=arm, audit_path=audit) as ctx:
                    ctx.run(dispatch_booking, planned, depends_on=[decision], boundary="dispatch_booking")
            except FreshnessBlocked as blocked:
                record("freshctx_boundary", state=blocked.result.state.value,
                       policy_decision=blocked.result.policy_decision,
                       boundary_outcome=blocked.correlation.boundary_outcome if blocked.correlation else None)
            else:
                record("freshctx_boundary", state=ctx.result.state.value,
                       policy_decision=ctx.result.policy_decision,
                       boundary_outcome=ctx.correlation.boundary_outcome)
        else:
            # The sole contrast: invoke the frozen action without revalidation.
            record("no_freshctx_boundary", decision_version=planned["planned_from_version"])
            dispatch_booking(planned)

        effects = [json.loads(line) for line in effect.read_text(encoding="utf-8").splitlines()] if effect.exists() else []
        record("effect_observed", count=len(effects), effects=effects)
        output.mkdir(parents=True, exist_ok=False)
        write_json(output / "before.json", INITIAL)
        write_json(output / "at_dispatch.json", CHANGED)
        write_json(output / "frozen_action.json", planned)
        write_json(output / "effects.json", effects)
        (output / "trace.jsonl").write_text("".join(json.dumps(event, sort_keys=True) + "\n" for event in trace), encoding="utf-8")
        if audit.exists():
            rows = []
            for line in audit.read_text(encoding="utf-8").splitlines():
                # Preserve FreshCtx's native event shape, IDs and result; remove the temporary workspace prefix.
                row = json.loads(line)
                encoded = json.dumps(row).replace(str(work), "fixture://workspace")
                rows.append(encoded)
            (output / "freshctx-audit.sanitized.jsonl").write_text("\n".join(rows) + "\n", encoding="utf-8")
        return {"arm": arm, "freshctx_state": next((x["state"] for x in trace if x["step"] == "freshctx_boundary"), None),
                "actual_effect_count": len(effects), "effect": effects}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "evidence")
    args = parser.parse_args()
    target = args.output.resolve()
    if target.exists():
        raise SystemExit(f"Output already exists: {target}. Select a new --output directory.")
    target.mkdir(parents=True)
    results = [run_arm(target / arm, arm) for arm in ("protected", "unprotected")]
    write_json(target / "comparison.json", {
        "source_before": INITIAL, "source_at_dispatch": CHANGED, "frozen_action": ACTION,
        "same_mutation_and_action_in_both_arms": True,
        "only_execution_difference": "FreshCtx ctx.run boundary versus direct call",
        "results": results,
        "scope": "Synthetic local filesystem test; not StareBrain or a calendar provider integration",
        "limitation": "A pre-dispatch freshness check does not make a remote action atomic with its source"})
    assert results[0]["freshctx_state"] == "STALE_REASONING" and results[0]["actual_effect_count"] == 0
    assert results[1]["actual_effect_count"] == 1 and results[1]["effect"] == [ACTION]
    print(json.dumps({"protected": results[0], "unprotected": results[1]}, indent=2))


if __name__ == "__main__":
    main()
